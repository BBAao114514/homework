# ROS Navigation Demo

本项目演示了如何在ROS中使用gmapping构建地图、使用move_base和AMCL完成导航、以及通过代码发送导航目标点。

## 内容包含

- `simple_goal.cpp`: 发送目标点代码
- `map/`: 保存地图数据（pgm+yaml）
- `launch/`: 导航配置文件（基于wpb_home）
- `README.md`: 教程指引

## 使用方法

### 1. 编译

将该包放入 `catkin_ws/src/` 下，进入 `catkin_ws` 执行：

```bash
catkin_make
```

### 2. 运行导航仿真

```bash
roslaunch wpr_simulation wpb_navigation.launch
```

用 Rviz 设置初始位姿（2D Pose Estimate），再设定目标（2D Nav Goal）。

### 3. 通过代码发送目标

```bash
rosrun ros_navigation_demo simple_goal
```

## 地图替换

将 `map/map.yaml` 和 `map/map.pgm` 拷贝至 `wpr_simulation/map/` 覆盖即可使用本地图。
